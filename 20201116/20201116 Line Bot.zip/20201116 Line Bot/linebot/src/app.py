import pymysql
import db
from flask import Flask, request, abort
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import *

#access token & channel secret
#line_bot_api物件:「操作」訊息，回應、發送、取得用戶資料
#handler物件:「處理」訊息，解讀或包裝訊息內容
line_bot_api = LineBotApi('7DYharYqY7fWsn99AGi6mXtYl92Mya5iRvJTTwxyqZTZxIGARoGBGBJSgNPvA0I9uqM93g5MtlhqRhvcLRZ+2iwT8HDVoyr1BgaFobqCyKh/Y0wcC+v4dzyiSEzplTG/h1+Lrv93z+ECOWhnbkWMmgdB04t89/1O/w1cDnyilFU=')
handler = WebhookHandler('9027ee6b55dbfa011d129a0e232c7fe8')

app = Flask(__name__)
#bot其實不需要處理瀏覽首頁的請求
@app.route('/')
def index():
    return 'Welcome to Line Bot!'

#接收post方法請求
@app.route("/callback", methods=['POST'])
def callback():
    signature = request.headers['X-Line-Signature']  #取HTTP標頭的密鑰欄位
    body = request.get_data(as_text=True)   #取HTTP body並轉成文字格式

    try:
        handler.handle(body, signature)     #結合body&金鑰驗證來源
    except InvalidSignatureError:       #若驗證來源失敗，傳回400中斷連接
        abort(400)

    return 'OK'

#接收任意類型LINE訊息的裝飾函式，程式沒意料到的
@handler.default()
def default(event):     #接收「訊息事件」的參數 = 被包裝成MessageEvent的webhook事件物件(JSON)
    print('捕捉到事件：', event)

@handler.add(FollowEvent)
def handle_follow(event):
    print('加入好友：', event)
    
    buttons_template = TemplateSendMessage(
        alt_text='Buttons Template',
        template=ButtonsTemplate(
            title='請點選您的性別',
            text='性別',
            thumbnail_image_url='https://i.imgur.com/6LHCwZa.png',
            actions=[
                PostbackAction(
                    label='男',
                    data='男'
                ),
                PostbackAction(
                    label='女',
                    data='女'
                )
            ]
        )
    )
    line_bot_api.reply_message(event.reply_token, buttons_template)
# 處理文字訊息
#(處理訊息事件, 訊息類型=文字)
#def 函式名稱(event=JSON資料=Webhook事件物件)
@handler.add(MessageEvent, message=TextMessage)
def handle_message(event):
    txt = event.message.text
    if (txt=='紀錄查詢'):
        buttons_template = TemplateSendMessage(
            alt_text='Buttons Template',
            template=ButtonsTemplate(
                title='請點選您的性別',
                text='性別',
                thumbnail_image_url='https://i.imgur.com/6LHCwZa.png',
                actions=[
                    PostbackAction(
                        label='男',
                        text = '男',
                        data= 'M'
                    ),
                    PostbackAction(
                        label='女',
                        text = '女',
                        data='F'
                    )
                ]
            )
        )
        line_bot_api.reply_message(event.reply_token, buttons_template)
    elif (txt in '男女') :
        date_picker = TemplateSendMessage(
            alt_text='輸入生日',
            template=ButtonsTemplate(
                title='請輸入生日',
                text='生日',
                actions=[
                    DatetimePickerAction(
                        label='設定',
                        data='action=buy&itemid=1',
                        mode='date',
                        initial='1995-04-01',
                        min='1920-04-01',
                        max='2020-12-31'
                    )
                ]
            )
        )
        line_bot_api.reply_message(event.reply_token, date_picker)
    #問電話
    #問地址



if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=80)


