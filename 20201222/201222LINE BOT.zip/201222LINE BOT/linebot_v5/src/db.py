import pymysql
import app
# 連接 MySQL 資料庫
print('ok')


def run(str,type):
    db = pymysql.connect(host="127.0.0.1",user="root", passwd="NTUB10656051", db="treasure_team",port=3306,charset='utf8')
    cursor = db.cursor()
    cursor.execute(str)
    print('okdb')
    if(type=="1"):
        return cursor.fetchall()
    
    db.close()



# 關閉連線
