import pymysql
import app
# 連接 MySQL 資料庫
db = pymysql.connect(host="140.131.114.149",user="10656051", passwd="NTUB10656051", db="treasure_team",port=3306,charset='utf8')
cursor = db.cursor()



# 關閉連線
db.close()