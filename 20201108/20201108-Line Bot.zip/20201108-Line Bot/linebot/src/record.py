import db

# 執行 MySQL 查詢指令
db.cursor.execute("SELECT Record_Recycling_number,Record_Recycling_time FROM treasure_recycling_record where Record_LINEid ='U0131826f2d23e1f17a3689d8574fd2cb'")

# 取回查詢結果
results = db.cursor.fetchone()
# 輸出結果
print(results)
